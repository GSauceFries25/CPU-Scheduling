﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cc_110
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            ((TextBox)form.Controls["A1"]).Text = J1.Text;
            ((TextBox)form.Controls["A2"]).Text = J2.Text;
            ((TextBox)form.Controls["A3"]).Text = J3.Text;
            ((TextBox)form.Controls["A4"]).Text = J4.Text;
            ((TextBox)form.Controls["A5"]).Text = J5.Text;

            ((TextBox)form.Controls["B0"]).Text = "0";
            ((TextBox)form.Controls["B1"]).Text = J6.Text;
            int a = Convert.ToInt32(J6.Text);
            int b = Convert.ToInt32(J7.Text);
            ((TextBox)form.Controls["B2"]).Text = Convert.ToString(a + b);
            int c = Convert.ToInt32(J8.Text);
            ((TextBox)form.Controls["B3"]).Text = Convert.ToString(a + b + c);
            int d = Convert.ToInt32(J9.Text);
            ((TextBox)form.Controls["B4"]).Text = Convert.ToString(a + b + c + d);
            int aa = Convert.ToInt32(J10.Text);
            ((TextBox)form.Controls["B5"]).Text = Convert.ToString(a + b + c + d + aa);

            form.Show();
            this.Hide();

            ((TextBox)form.Controls["JJ1"]).Text = J1.Text;
            ((TextBox)form.Controls["JJ2"]).Text = J2.Text;
            ((TextBox)form.Controls["JJ3"]).Text = J3.Text;
            ((TextBox)form.Controls["JJ4"]).Text = J4.Text;
            ((TextBox)form.Controls["JJ5"]).Text = J5.Text;

            ((TextBox)form.Controls["JJ6"]).Text = J6.Text;
            ((TextBox)form.Controls["JJ7"]).Text = J7.Text;
            ((TextBox)form.Controls["JJ8"]).Text = J8.Text;
            ((TextBox)form.Controls["JJ9"]).Text = J9.Text;
            ((TextBox)form.Controls["JJ10"]).Text = J10.Text;

            ((TextBox)form.Controls["JJ11"]).Text = J11.Text;
            ((TextBox)form.Controls["JJ12"]).Text = J12.Text;
            ((TextBox)form.Controls["JJ13"]).Text = J13.Text;
            ((TextBox)form.Controls["JJ14"]).Text = J14.Text;
            ((TextBox)form.Controls["JJ15"]).Text = J15.Text;

            ((TextBox)form.Controls["JJ16"]).Text = J16.Text;
            ((TextBox)form.Controls["JJ17"]).Text = J17.Text;
            ((TextBox)form.Controls["JJ18"]).Text = J18.Text;
            ((TextBox)form.Controls["JJ19"]).Text = J19.Text;
            ((TextBox)form.Controls["JJ20"]).Text = J20.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 frm5 = new Form5();
            frm5.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            ((TextBox)form.Controls["X1"]).Text = J1.Text;
            ((TextBox)form.Controls["X2"]).Text = J2.Text;
            ((TextBox)form.Controls["X3"]).Text = J3.Text;
            ((TextBox)form.Controls["X4"]).Text = J4.Text;
            ((TextBox)form.Controls["X5"]).Text = J5.Text;

            ((TextBox)form.Controls["Q0"]).Text = "0";
            ((TextBox)form.Controls["Q1"]).Text = J6.Text;
            int a = Convert.ToInt32(J6.Text);
            int b = Convert.ToInt32(J7.Text);
            ((TextBox)form.Controls["Q2"]).Text = Convert.ToString(a + b);
            int c = Convert.ToInt32(J8.Text);
            ((TextBox)form.Controls["Q3"]).Text = Convert.ToString(a + b + c);
            int d = Convert.ToInt32(J9.Text);
            ((TextBox)form.Controls["Q4"]).Text = Convert.ToString(a + b + c + d);
            int aa = Convert.ToInt32(J10.Text);
            ((TextBox)form.Controls["Q5"]).Text = Convert.ToString(a + b + c + d + aa);

            form.Show();
            this.Hide();

            ((TextBox)form.Controls["K1"]).Text = J1.Text;
            ((TextBox)form.Controls["K2"]).Text = J2.Text;
            ((TextBox)form.Controls["K3"]).Text = J3.Text;
            ((TextBox)form.Controls["K4"]).Text = J4.Text;
            ((TextBox)form.Controls["K5"]).Text = J5.Text;

            ((TextBox)form.Controls["K6"]).Text = J6.Text;
            ((TextBox)form.Controls["K7"]).Text = J7.Text;
            ((TextBox)form.Controls["K8"]).Text = J8.Text;
            ((TextBox)form.Controls["K9"]).Text = J9.Text;
            ((TextBox)form.Controls["K10"]).Text = J10.Text;

            ((TextBox)form.Controls["K11"]).Text = J11.Text;
            ((TextBox)form.Controls["K12"]).Text = J12.Text;
            ((TextBox)form.Controls["K13"]).Text = J13.Text;
            ((TextBox)form.Controls["K14"]).Text = J14.Text;
            ((TextBox)form.Controls["K15"]).Text = J15.Text;

            ((TextBox)form.Controls["K16"]).Text = J16.Text;
            ((TextBox)form.Controls["K17"]).Text = J17.Text;
            ((TextBox)form.Controls["K18"]).Text = J18.Text;
            ((TextBox)form.Controls["K19"]).Text = J19.Text;
            ((TextBox)form.Controls["KK20"]).Text = J20.Text;
        }
    }
}
