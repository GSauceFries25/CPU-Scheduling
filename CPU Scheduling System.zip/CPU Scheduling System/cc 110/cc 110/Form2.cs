﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cc_110
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            ((TextBox)form.Controls["C1"]).Text = A1.Text;
            ((TextBox)form.Controls["C2"]).Text = A2.Text;
            ((TextBox)form.Controls["C3"]).Text = A3.Text;
            ((TextBox)form.Controls["C4"]).Text = A4.Text;
            ((TextBox)form.Controls["C5"]).Text = A5.Text;

            ((TextBox)form.Controls["C6"]).Text = B0.Text;
            ((TextBox)form.Controls["C7"]).Text = B1.Text;
            ((TextBox)form.Controls["C8"]).Text = B2.Text;
            ((TextBox)form.Controls["C9"]).Text = B3.Text;
            ((TextBox)form.Controls["C10"]).Text = B4.Text;

            ((TextBox)form.Controls["C11"]).Text = JJ11.Text;
            ((TextBox)form.Controls["C12"]).Text = JJ12.Text;
            ((TextBox)form.Controls["C13"]).Text = JJ13.Text;
            ((TextBox)form.Controls["C14"]).Text = JJ14.Text;
            ((TextBox)form.Controls["C15"]).Text = JJ15.Text;

            ((TextBox)form.Controls["Z1"]).Text = A1.Text;
            ((TextBox)form.Controls["Z2"]).Text = A2.Text;
            ((TextBox)form.Controls["Z3"]).Text = A3.Text;
            ((TextBox)form.Controls["Z4"]).Text = A4.Text;
            ((TextBox)form.Controls["Z5"]).Text = A5.Text;

            ((TextBox)form.Controls["Z6"]).Text = B1.Text;
            ((TextBox)form.Controls["Z7"]).Text = B2.Text;
            ((TextBox)form.Controls["Z8"]).Text = B3.Text;
            ((TextBox)form.Controls["Z9"]).Text = B4.Text;
            ((TextBox)form.Controls["Z10"]).Text = B5.Text;

            ((TextBox)form.Controls["Z11"]).Text = JJ11.Text;
            ((TextBox)form.Controls["Z12"]).Text = JJ12.Text;
            ((TextBox)form.Controls["Z13"]).Text = JJ13.Text;
            ((TextBox)form.Controls["Z14"]).Text = JJ14.Text;
            ((TextBox)form.Controls["Z15"]).Text = JJ15.Text;

            form.Show();
            this.Hide();
        }
    }
}
