﻿
namespace cc_110
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.C1 = new System.Windows.Forms.TextBox();
            this.C2 = new System.Windows.Forms.TextBox();
            this.C3 = new System.Windows.Forms.TextBox();
            this.C4 = new System.Windows.Forms.TextBox();
            this.C5 = new System.Windows.Forms.TextBox();
            this.C10 = new System.Windows.Forms.TextBox();
            this.C9 = new System.Windows.Forms.TextBox();
            this.C8 = new System.Windows.Forms.TextBox();
            this.C7 = new System.Windows.Forms.TextBox();
            this.C6 = new System.Windows.Forms.TextBox();
            this.C15 = new System.Windows.Forms.TextBox();
            this.C14 = new System.Windows.Forms.TextBox();
            this.C13 = new System.Windows.Forms.TextBox();
            this.C12 = new System.Windows.Forms.TextBox();
            this.C11 = new System.Windows.Forms.TextBox();
            this.CC5 = new System.Windows.Forms.TextBox();
            this.CC4 = new System.Windows.Forms.TextBox();
            this.CC3 = new System.Windows.Forms.TextBox();
            this.CC2 = new System.Windows.Forms.TextBox();
            this.CC1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.CC6 = new System.Windows.Forms.TextBox();
            this.CC7 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.Z22 = new System.Windows.Forms.TextBox();
            this.Z21 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.Z20 = new System.Windows.Forms.TextBox();
            this.Z19 = new System.Windows.Forms.TextBox();
            this.Z18 = new System.Windows.Forms.TextBox();
            this.Z17 = new System.Windows.Forms.TextBox();
            this.Z16 = new System.Windows.Forms.TextBox();
            this.Z15 = new System.Windows.Forms.TextBox();
            this.Z14 = new System.Windows.Forms.TextBox();
            this.Z13 = new System.Windows.Forms.TextBox();
            this.Z12 = new System.Windows.Forms.TextBox();
            this.Z11 = new System.Windows.Forms.TextBox();
            this.Z10 = new System.Windows.Forms.TextBox();
            this.Z9 = new System.Windows.Forms.TextBox();
            this.Z8 = new System.Windows.Forms.TextBox();
            this.Z7 = new System.Windows.Forms.TextBox();
            this.Z6 = new System.Windows.Forms.TextBox();
            this.Z5 = new System.Windows.Forms.TextBox();
            this.Z4 = new System.Windows.Forms.TextBox();
            this.Z3 = new System.Windows.Forms.TextBox();
            this.Z2 = new System.Windows.Forms.TextBox();
            this.Z1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // C1
            // 
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.Location = new System.Drawing.Point(26, 144);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(56, 41);
            this.C1.TabIndex = 5;
            // 
            // C2
            // 
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(26, 191);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(56, 41);
            this.C2.TabIndex = 6;
            // 
            // C3
            // 
            this.C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(26, 238);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(56, 41);
            this.C3.TabIndex = 7;
            // 
            // C4
            // 
            this.C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.Location = new System.Drawing.Point(26, 285);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(56, 41);
            this.C4.TabIndex = 8;
            // 
            // C5
            // 
            this.C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.Location = new System.Drawing.Point(26, 332);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(56, 41);
            this.C5.TabIndex = 9;
            // 
            // C10
            // 
            this.C10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C10.Location = new System.Drawing.Point(142, 332);
            this.C10.Name = "C10";
            this.C10.Size = new System.Drawing.Size(56, 41);
            this.C10.TabIndex = 14;
            // 
            // C9
            // 
            this.C9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C9.Location = new System.Drawing.Point(142, 285);
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(56, 41);
            this.C9.TabIndex = 13;
            // 
            // C8
            // 
            this.C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.Location = new System.Drawing.Point(142, 238);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(56, 41);
            this.C8.TabIndex = 12;
            // 
            // C7
            // 
            this.C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.Location = new System.Drawing.Point(142, 191);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(56, 41);
            this.C7.TabIndex = 11;
            // 
            // C6
            // 
            this.C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.Location = new System.Drawing.Point(142, 144);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(56, 41);
            this.C6.TabIndex = 10;
            // 
            // C15
            // 
            this.C15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C15.Location = new System.Drawing.Point(262, 329);
            this.C15.Name = "C15";
            this.C15.Size = new System.Drawing.Size(56, 41);
            this.C15.TabIndex = 19;
            // 
            // C14
            // 
            this.C14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C14.Location = new System.Drawing.Point(262, 282);
            this.C14.Name = "C14";
            this.C14.Size = new System.Drawing.Size(56, 41);
            this.C14.TabIndex = 18;
            // 
            // C13
            // 
            this.C13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C13.Location = new System.Drawing.Point(262, 235);
            this.C13.Name = "C13";
            this.C13.Size = new System.Drawing.Size(56, 41);
            this.C13.TabIndex = 17;
            // 
            // C12
            // 
            this.C12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C12.Location = new System.Drawing.Point(262, 188);
            this.C12.Name = "C12";
            this.C12.Size = new System.Drawing.Size(56, 41);
            this.C12.TabIndex = 16;
            // 
            // C11
            // 
            this.C11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C11.Location = new System.Drawing.Point(262, 141);
            this.C11.Name = "C11";
            this.C11.Size = new System.Drawing.Size(56, 41);
            this.C11.TabIndex = 15;
            // 
            // CC5
            // 
            this.CC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC5.Location = new System.Drawing.Point(390, 329);
            this.CC5.Name = "CC5";
            this.CC5.Size = new System.Drawing.Size(56, 41);
            this.CC5.TabIndex = 24;
            // 
            // CC4
            // 
            this.CC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC4.Location = new System.Drawing.Point(390, 282);
            this.CC4.Name = "CC4";
            this.CC4.Size = new System.Drawing.Size(56, 41);
            this.CC4.TabIndex = 23;
            // 
            // CC3
            // 
            this.CC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC3.Location = new System.Drawing.Point(390, 235);
            this.CC3.Name = "CC3";
            this.CC3.Size = new System.Drawing.Size(56, 41);
            this.CC3.TabIndex = 22;
            // 
            // CC2
            // 
            this.CC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC2.Location = new System.Drawing.Point(390, 188);
            this.CC2.Name = "CC2";
            this.CC2.Size = new System.Drawing.Size(56, 41);
            this.CC2.TabIndex = 21;
            // 
            // CC1
            // 
            this.CC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC1.Location = new System.Drawing.Point(390, 141);
            this.CC1.Name = "CC1";
            this.CC1.Size = new System.Drawing.Size(56, 41);
            this.CC1.TabIndex = 20;
            this.CC1.TextChanged += new System.EventHandler(this.CC1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(98, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 36);
            this.label1.TabIndex = 25;
            this.label1.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(98, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 36);
            this.label2.TabIndex = 26;
            this.label2.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(98, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 36);
            this.label3.TabIndex = 27;
            this.label3.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(98, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 36);
            this.label4.TabIndex = 28;
            this.label4.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(98, 332);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 36);
            this.label5.TabIndex = 29;
            this.label5.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(221, 332);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 36);
            this.label6.TabIndex = 34;
            this.label6.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(221, 285);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 36);
            this.label7.TabIndex = 33;
            this.label7.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(221, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 36);
            this.label8.TabIndex = 32;
            this.label8.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(221, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 36);
            this.label9.TabIndex = 31;
            this.label9.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(221, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 36);
            this.label10.TabIndex = 30;
            this.label10.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(342, 153);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 29);
            this.label11.TabIndex = 35;
            this.label11.Text = "=";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(342, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 29);
            this.label12.TabIndex = 36;
            this.label12.Text = "=";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(342, 245);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 29);
            this.label13.TabIndex = 37;
            this.label13.Text = "=";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.Location = new System.Drawing.Point(342, 291);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 29);
            this.label14.TabIndex = 38;
            this.label14.Text = "=";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.Location = new System.Drawing.Point(342, 336);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 29);
            this.label15.TabIndex = 39;
            this.label15.Text = "=";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(57, 71);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(355, 32);
            this.label16.TabIndex = 40;
            this.label16.Text = "AWT - INITIAL TIME = AT";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(26, 394);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 34);
            this.button1.TabIndex = 41;
            this.button1.Text = "answer";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CC6
            // 
            this.CC6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC6.Location = new System.Drawing.Point(347, 385);
            this.CC6.Name = "CC6";
            this.CC6.Size = new System.Drawing.Size(99, 30);
            this.CC6.TabIndex = 42;
            // 
            // CC7
            // 
            this.CC7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CC7.Location = new System.Drawing.Point(347, 421);
            this.CC7.Name = "CC7";
            this.CC7.Size = new System.Drawing.Size(99, 30);
            this.CC7.TabIndex = 43;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label32.Location = new System.Drawing.Point(544, 71);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(411, 32);
            this.label32.TabIndex = 82;
            this.label32.Text = "ATA - COMPLETE TIME = AT";
            // 
            // Z22
            // 
            this.Z22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z22.Location = new System.Drawing.Point(860, 419);
            this.Z22.Name = "Z22";
            this.Z22.Size = new System.Drawing.Size(99, 30);
            this.Z22.TabIndex = 120;
            // 
            // Z21
            // 
            this.Z21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z21.Location = new System.Drawing.Point(860, 383);
            this.Z21.Name = "Z21";
            this.Z21.Size = new System.Drawing.Size(99, 30);
            this.Z21.TabIndex = 119;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(539, 392);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 34);
            this.button2.TabIndex = 118;
            this.button2.Text = "answer";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(855, 334);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(28, 29);
            this.label17.TabIndex = 117;
            this.label17.Text = "=";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.Location = new System.Drawing.Point(855, 289);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(28, 29);
            this.label18.TabIndex = 116;
            this.label18.Text = "=";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label19.Location = new System.Drawing.Point(855, 243);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(28, 29);
            this.label19.TabIndex = 115;
            this.label19.Text = "=";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label20.Location = new System.Drawing.Point(855, 201);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 29);
            this.label20.TabIndex = 114;
            this.label20.Text = "=";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label21.Location = new System.Drawing.Point(855, 151);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(28, 29);
            this.label21.TabIndex = 113;
            this.label21.Text = "=";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label22.Location = new System.Drawing.Point(734, 330);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 36);
            this.label22.TabIndex = 112;
            this.label22.Text = "-";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label23.Location = new System.Drawing.Point(734, 283);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 36);
            this.label23.TabIndex = 111;
            this.label23.Text = "-";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label24.Location = new System.Drawing.Point(734, 236);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 36);
            this.label24.TabIndex = 110;
            this.label24.Text = "-";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label25.Location = new System.Drawing.Point(734, 189);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 36);
            this.label25.TabIndex = 109;
            this.label25.Text = "-";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label26.Location = new System.Drawing.Point(734, 144);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 36);
            this.label26.TabIndex = 108;
            this.label26.Text = "-";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label27.Location = new System.Drawing.Point(611, 330);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 36);
            this.label27.TabIndex = 107;
            this.label27.Text = "-";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label28.Location = new System.Drawing.Point(611, 283);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 36);
            this.label28.TabIndex = 106;
            this.label28.Text = "-";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label29.Location = new System.Drawing.Point(611, 236);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 36);
            this.label29.TabIndex = 105;
            this.label29.Text = "-";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Location = new System.Drawing.Point(611, 189);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(26, 36);
            this.label30.TabIndex = 104;
            this.label30.Text = "-";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label31.Location = new System.Drawing.Point(611, 144);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(26, 36);
            this.label31.TabIndex = 103;
            this.label31.Text = "-";
            // 
            // Z20
            // 
            this.Z20.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z20.Location = new System.Drawing.Point(903, 327);
            this.Z20.Name = "Z20";
            this.Z20.Size = new System.Drawing.Size(56, 41);
            this.Z20.TabIndex = 102;
            // 
            // Z19
            // 
            this.Z19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z19.Location = new System.Drawing.Point(903, 280);
            this.Z19.Name = "Z19";
            this.Z19.Size = new System.Drawing.Size(56, 41);
            this.Z19.TabIndex = 101;
            // 
            // Z18
            // 
            this.Z18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z18.Location = new System.Drawing.Point(903, 233);
            this.Z18.Name = "Z18";
            this.Z18.Size = new System.Drawing.Size(56, 41);
            this.Z18.TabIndex = 100;
            // 
            // Z17
            // 
            this.Z17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z17.Location = new System.Drawing.Point(903, 186);
            this.Z17.Name = "Z17";
            this.Z17.Size = new System.Drawing.Size(56, 41);
            this.Z17.TabIndex = 99;
            // 
            // Z16
            // 
            this.Z16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z16.Location = new System.Drawing.Point(903, 139);
            this.Z16.Name = "Z16";
            this.Z16.Size = new System.Drawing.Size(56, 41);
            this.Z16.TabIndex = 98;
            // 
            // Z15
            // 
            this.Z15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z15.Location = new System.Drawing.Point(775, 327);
            this.Z15.Name = "Z15";
            this.Z15.Size = new System.Drawing.Size(56, 41);
            this.Z15.TabIndex = 97;
            // 
            // Z14
            // 
            this.Z14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z14.Location = new System.Drawing.Point(775, 280);
            this.Z14.Name = "Z14";
            this.Z14.Size = new System.Drawing.Size(56, 41);
            this.Z14.TabIndex = 96;
            // 
            // Z13
            // 
            this.Z13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z13.Location = new System.Drawing.Point(775, 233);
            this.Z13.Name = "Z13";
            this.Z13.Size = new System.Drawing.Size(56, 41);
            this.Z13.TabIndex = 95;
            // 
            // Z12
            // 
            this.Z12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z12.Location = new System.Drawing.Point(775, 186);
            this.Z12.Name = "Z12";
            this.Z12.Size = new System.Drawing.Size(56, 41);
            this.Z12.TabIndex = 94;
            // 
            // Z11
            // 
            this.Z11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z11.Location = new System.Drawing.Point(775, 139);
            this.Z11.Name = "Z11";
            this.Z11.Size = new System.Drawing.Size(56, 41);
            this.Z11.TabIndex = 93;
            // 
            // Z10
            // 
            this.Z10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z10.Location = new System.Drawing.Point(655, 330);
            this.Z10.Name = "Z10";
            this.Z10.Size = new System.Drawing.Size(56, 41);
            this.Z10.TabIndex = 92;
            // 
            // Z9
            // 
            this.Z9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z9.Location = new System.Drawing.Point(655, 283);
            this.Z9.Name = "Z9";
            this.Z9.Size = new System.Drawing.Size(56, 41);
            this.Z9.TabIndex = 91;
            // 
            // Z8
            // 
            this.Z8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z8.Location = new System.Drawing.Point(655, 236);
            this.Z8.Name = "Z8";
            this.Z8.Size = new System.Drawing.Size(56, 41);
            this.Z8.TabIndex = 90;
            // 
            // Z7
            // 
            this.Z7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z7.Location = new System.Drawing.Point(655, 189);
            this.Z7.Name = "Z7";
            this.Z7.Size = new System.Drawing.Size(56, 41);
            this.Z7.TabIndex = 89;
            // 
            // Z6
            // 
            this.Z6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z6.Location = new System.Drawing.Point(655, 142);
            this.Z6.Name = "Z6";
            this.Z6.Size = new System.Drawing.Size(56, 41);
            this.Z6.TabIndex = 88;
            // 
            // Z5
            // 
            this.Z5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z5.Location = new System.Drawing.Point(539, 330);
            this.Z5.Name = "Z5";
            this.Z5.Size = new System.Drawing.Size(56, 41);
            this.Z5.TabIndex = 87;
            // 
            // Z4
            // 
            this.Z4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z4.Location = new System.Drawing.Point(539, 283);
            this.Z4.Name = "Z4";
            this.Z4.Size = new System.Drawing.Size(56, 41);
            this.Z4.TabIndex = 86;
            // 
            // Z3
            // 
            this.Z3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z3.Location = new System.Drawing.Point(539, 236);
            this.Z3.Name = "Z3";
            this.Z3.Size = new System.Drawing.Size(56, 41);
            this.Z3.TabIndex = 85;
            // 
            // Z2
            // 
            this.Z2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z2.Location = new System.Drawing.Point(539, 189);
            this.Z2.Name = "Z2";
            this.Z2.Size = new System.Drawing.Size(56, 41);
            this.Z2.TabIndex = 84;
            // 
            // Z1
            // 
            this.Z1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Z1.Location = new System.Drawing.Point(539, 142);
            this.Z1.Name = "Z1";
            this.Z1.Size = new System.Drawing.Size(56, 41);
            this.Z1.TabIndex = 83;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(434, 475);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 31);
            this.button3.TabIndex = 121;
            this.button3.Text = "BACK";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(984, 518);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Z22);
            this.Controls.Add(this.Z21);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.Z20);
            this.Controls.Add(this.Z19);
            this.Controls.Add(this.Z18);
            this.Controls.Add(this.Z17);
            this.Controls.Add(this.Z16);
            this.Controls.Add(this.Z15);
            this.Controls.Add(this.Z14);
            this.Controls.Add(this.Z13);
            this.Controls.Add(this.Z12);
            this.Controls.Add(this.Z11);
            this.Controls.Add(this.Z10);
            this.Controls.Add(this.Z9);
            this.Controls.Add(this.Z8);
            this.Controls.Add(this.Z7);
            this.Controls.Add(this.Z6);
            this.Controls.Add(this.Z5);
            this.Controls.Add(this.Z4);
            this.Controls.Add(this.Z3);
            this.Controls.Add(this.Z2);
            this.Controls.Add(this.Z1);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.CC7);
            this.Controls.Add(this.CC6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CC5);
            this.Controls.Add(this.CC4);
            this.Controls.Add(this.CC3);
            this.Controls.Add(this.CC2);
            this.Controls.Add(this.CC1);
            this.Controls.Add(this.C15);
            this.Controls.Add(this.C14);
            this.Controls.Add(this.C13);
            this.Controls.Add(this.C12);
            this.Controls.Add(this.C11);
            this.Controls.Add(this.C10);
            this.Controls.Add(this.C9);
            this.Controls.Add(this.C8);
            this.Controls.Add(this.C7);
            this.Controls.Add(this.C6);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.C1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "COMPUTATION";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox C1;
        private System.Windows.Forms.TextBox C2;
        private System.Windows.Forms.TextBox C3;
        private System.Windows.Forms.TextBox C4;
        private System.Windows.Forms.TextBox C5;
        private System.Windows.Forms.TextBox C10;
        private System.Windows.Forms.TextBox C9;
        private System.Windows.Forms.TextBox C8;
        private System.Windows.Forms.TextBox C7;
        private System.Windows.Forms.TextBox C6;
        private System.Windows.Forms.TextBox C15;
        private System.Windows.Forms.TextBox C14;
        private System.Windows.Forms.TextBox C13;
        private System.Windows.Forms.TextBox C12;
        private System.Windows.Forms.TextBox C11;
        private System.Windows.Forms.TextBox CC5;
        private System.Windows.Forms.TextBox CC4;
        private System.Windows.Forms.TextBox CC3;
        private System.Windows.Forms.TextBox CC2;
        private System.Windows.Forms.TextBox CC1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox CC6;
        private System.Windows.Forms.TextBox CC7;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox Z22;
        private System.Windows.Forms.TextBox Z21;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox Z20;
        private System.Windows.Forms.TextBox Z19;
        private System.Windows.Forms.TextBox Z18;
        private System.Windows.Forms.TextBox Z17;
        private System.Windows.Forms.TextBox Z16;
        private System.Windows.Forms.TextBox Z15;
        private System.Windows.Forms.TextBox Z14;
        private System.Windows.Forms.TextBox Z13;
        private System.Windows.Forms.TextBox Z12;
        private System.Windows.Forms.TextBox Z11;
        private System.Windows.Forms.TextBox Z10;
        private System.Windows.Forms.TextBox Z9;
        private System.Windows.Forms.TextBox Z8;
        private System.Windows.Forms.TextBox Z7;
        private System.Windows.Forms.TextBox Z6;
        private System.Windows.Forms.TextBox Z5;
        private System.Windows.Forms.TextBox Z4;
        private System.Windows.Forms.TextBox Z3;
        private System.Windows.Forms.TextBox Z2;
        private System.Windows.Forms.TextBox Z1;
        private System.Windows.Forms.Button button3;
    }
}