﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cc_110
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(C6.Text);
            int b = Convert.ToInt32(C11.Text);
            CC1.Text = Convert.ToString(a - b);

            int c = Convert.ToInt32(C7.Text);
            int d = Convert.ToInt32(C12.Text);
            CC2.Text = Convert.ToString(c - d);

            int aa = Convert.ToInt32(C8.Text);
            int bb = Convert.ToInt32(C13.Text);
            CC3.Text = Convert.ToString(aa - bb);

            int ab = Convert.ToInt32(C9.Text);
            int ba = Convert.ToInt32(C14.Text);
            CC4.Text = Convert.ToString(ab - ba);

            int aaa = Convert.ToInt32(C10.Text);
            int bbb = Convert.ToInt32(C15.Text);
            CC5.Text = Convert.ToString(aaa - bbb);

            int z = Convert.ToInt32(CC1.Text);
            int x = Convert.ToInt32(CC2.Text);
            int m = Convert.ToInt32(CC3.Text);
            int o = Convert.ToInt32(CC4.Text);
            int p = Convert.ToInt32(CC5.Text);
            CC6.Text = Convert.ToString(z + x + m + o + p);

            decimal num1 = Convert.ToDecimal(CC6.Text);
            decimal num2 = Convert.ToDecimal(5);
            decimal answ = num1 / num2;
            CC7.Text = answ.ToString() + "ms";
        }

        private void CC1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(Z6.Text);
            int b = Convert.ToInt32(Z11.Text);
            Z16.Text = Convert.ToString(a - b);

            int c = Convert.ToInt32(Z7.Text);
            int d = Convert.ToInt32(Z12.Text);
            Z17.Text = Convert.ToString(c - d);

            int aa = Convert.ToInt32(Z8.Text);
            int bb = Convert.ToInt32(Z13.Text);
            Z18.Text = Convert.ToString(aa - bb);

            int ab = Convert.ToInt32(Z9.Text);
            int ba = Convert.ToInt32(Z14.Text);
            Z19.Text = Convert.ToString(ab - ba);

            int aaa = Convert.ToInt32(Z10.Text);
            int bbb = Convert.ToInt32(Z15.Text);
            Z20.Text = Convert.ToString(aaa - bbb);

            int z = Convert.ToInt32(Z16.Text);
            int x = Convert.ToInt32(Z17.Text);
            int m = Convert.ToInt32(Z18.Text);
            int o = Convert.ToInt32(Z19.Text);
            int p = Convert.ToInt32(Z20.Text);
            Z21.Text = Convert.ToString(z + x + m + o + p);

            decimal num1 = Convert.ToDecimal(Z21.Text);
            decimal num2 = Convert.ToDecimal(5);
            decimal answ = num1 / num2;
            Z22.Text = answ.ToString() + "ms";


        }
    }
}
