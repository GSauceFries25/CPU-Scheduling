﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cc_110
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            ((TextBox)form.Controls["E1"]).Text = K1.Text;
            ((TextBox)form.Controls["E2"]).Text = K2.Text;
            ((TextBox)form.Controls["E3"]).Text = K3.Text;
            ((TextBox)form.Controls["E4"]).Text = K4.Text;
            ((TextBox)form.Controls["E5"]).Text = K5.Text;

            ((TextBox)form.Controls["E6"]).Text = Q0.Text;
            ((TextBox)form.Controls["E7"]).Text = Q1.Text;
            ((TextBox)form.Controls["E8"]).Text = Q2.Text;
            ((TextBox)form.Controls["E9"]).Text = Q3.Text;
            ((TextBox)form.Controls["E10"]).Text = Q4.Text;

            ((TextBox)form.Controls["E11"]).Text = K16.Text;
            ((TextBox)form.Controls["E12"]).Text = K17.Text;
            ((TextBox)form.Controls["E13"]).Text = K18.Text;
            ((TextBox)form.Controls["E14"]).Text = K19.Text;
            ((TextBox)form.Controls["E15"]).Text = KK20.Text;

            ((TextBox)form.Controls["T1"]).Text = K1.Text;
            ((TextBox)form.Controls["T2"]).Text = K2.Text;
            ((TextBox)form.Controls["T3"]).Text = K3.Text;
            ((TextBox)form.Controls["T4"]).Text = K4.Text;
            ((TextBox)form.Controls["T5"]).Text = K5.Text;

            ((TextBox)form.Controls["T6"]).Text = Q1.Text;
            ((TextBox)form.Controls["T7"]).Text = Q2.Text;
            ((TextBox)form.Controls["T8"]).Text = Q3.Text;
            ((TextBox)form.Controls["T9"]).Text = Q4.Text;
            ((TextBox)form.Controls["T10"]).Text = Q5.Text;

            ((TextBox)form.Controls["T11"]).Text = K16.Text;
            ((TextBox)form.Controls["T12"]).Text = K17.Text;
            ((TextBox)form.Controls["T13"]).Text = K18.Text;
            ((TextBox)form.Controls["T14"]).Text = K19.Text;
            ((TextBox)form.Controls["T15"]).Text = KK20.Text;

            form.Show();
            this.Hide();
        }
    }
}
