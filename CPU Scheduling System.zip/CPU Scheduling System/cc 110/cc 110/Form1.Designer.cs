﻿
namespace cc_110
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.J1 = new System.Windows.Forms.TextBox();
            this.J2 = new System.Windows.Forms.TextBox();
            this.J3 = new System.Windows.Forms.TextBox();
            this.J4 = new System.Windows.Forms.TextBox();
            this.J5 = new System.Windows.Forms.TextBox();
            this.J10 = new System.Windows.Forms.TextBox();
            this.J9 = new System.Windows.Forms.TextBox();
            this.J8 = new System.Windows.Forms.TextBox();
            this.J7 = new System.Windows.Forms.TextBox();
            this.J6 = new System.Windows.Forms.TextBox();
            this.J15 = new System.Windows.Forms.TextBox();
            this.J14 = new System.Windows.Forms.TextBox();
            this.J13 = new System.Windows.Forms.TextBox();
            this.J12 = new System.Windows.Forms.TextBox();
            this.J11 = new System.Windows.Forms.TextBox();
            this.J20 = new System.Windows.Forms.TextBox();
            this.J19 = new System.Windows.Forms.TextBox();
            this.J18 = new System.Windows.Forms.TextBox();
            this.J17 = new System.Windows.Forms.TextBox();
            this.J16 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(89, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "JOBS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(167, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "BT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(229, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "AT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(288, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "AT";
            // 
            // J1
            // 
            this.J1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J1.Location = new System.Drawing.Point(92, 142);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(56, 41);
            this.J1.TabIndex = 4;
            // 
            // J2
            // 
            this.J2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J2.Location = new System.Drawing.Point(92, 176);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(56, 41);
            this.J2.TabIndex = 5;
            // 
            // J3
            // 
            this.J3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J3.Location = new System.Drawing.Point(92, 210);
            this.J3.Name = "J3";
            this.J3.Size = new System.Drawing.Size(56, 41);
            this.J3.TabIndex = 6;
            // 
            // J4
            // 
            this.J4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J4.Location = new System.Drawing.Point(92, 244);
            this.J4.Name = "J4";
            this.J4.Size = new System.Drawing.Size(56, 41);
            this.J4.TabIndex = 7;
            // 
            // J5
            // 
            this.J5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J5.Location = new System.Drawing.Point(92, 278);
            this.J5.Name = "J5";
            this.J5.Size = new System.Drawing.Size(56, 41);
            this.J5.TabIndex = 8;
            // 
            // J10
            // 
            this.J10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J10.Location = new System.Drawing.Point(154, 278);
            this.J10.Name = "J10";
            this.J10.Size = new System.Drawing.Size(56, 41);
            this.J10.TabIndex = 13;
            // 
            // J9
            // 
            this.J9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J9.Location = new System.Drawing.Point(154, 244);
            this.J9.Name = "J9";
            this.J9.Size = new System.Drawing.Size(56, 41);
            this.J9.TabIndex = 12;
            // 
            // J8
            // 
            this.J8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J8.Location = new System.Drawing.Point(154, 210);
            this.J8.Name = "J8";
            this.J8.Size = new System.Drawing.Size(56, 41);
            this.J8.TabIndex = 11;
            // 
            // J7
            // 
            this.J7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J7.Location = new System.Drawing.Point(154, 176);
            this.J7.Name = "J7";
            this.J7.Size = new System.Drawing.Size(56, 41);
            this.J7.TabIndex = 10;
            // 
            // J6
            // 
            this.J6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J6.Location = new System.Drawing.Point(154, 142);
            this.J6.Name = "J6";
            this.J6.Size = new System.Drawing.Size(56, 41);
            this.J6.TabIndex = 9;
            // 
            // J15
            // 
            this.J15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J15.Location = new System.Drawing.Point(216, 278);
            this.J15.Name = "J15";
            this.J15.Size = new System.Drawing.Size(56, 41);
            this.J15.TabIndex = 18;
            // 
            // J14
            // 
            this.J14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J14.Location = new System.Drawing.Point(216, 244);
            this.J14.Name = "J14";
            this.J14.Size = new System.Drawing.Size(56, 41);
            this.J14.TabIndex = 17;
            // 
            // J13
            // 
            this.J13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J13.Location = new System.Drawing.Point(216, 210);
            this.J13.Name = "J13";
            this.J13.Size = new System.Drawing.Size(56, 41);
            this.J13.TabIndex = 16;
            // 
            // J12
            // 
            this.J12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J12.Location = new System.Drawing.Point(216, 176);
            this.J12.Name = "J12";
            this.J12.Size = new System.Drawing.Size(56, 41);
            this.J12.TabIndex = 15;
            // 
            // J11
            // 
            this.J11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J11.Location = new System.Drawing.Point(216, 142);
            this.J11.Name = "J11";
            this.J11.Size = new System.Drawing.Size(56, 41);
            this.J11.TabIndex = 14;
            // 
            // J20
            // 
            this.J20.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J20.Location = new System.Drawing.Point(278, 278);
            this.J20.Name = "J20";
            this.J20.Size = new System.Drawing.Size(56, 41);
            this.J20.TabIndex = 23;
            // 
            // J19
            // 
            this.J19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J19.Location = new System.Drawing.Point(278, 244);
            this.J19.Name = "J19";
            this.J19.Size = new System.Drawing.Size(56, 41);
            this.J19.TabIndex = 22;
            // 
            // J18
            // 
            this.J18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J18.Location = new System.Drawing.Point(278, 210);
            this.J18.Name = "J18";
            this.J18.Size = new System.Drawing.Size(56, 41);
            this.J18.TabIndex = 21;
            // 
            // J17
            // 
            this.J17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J17.Location = new System.Drawing.Point(278, 176);
            this.J17.Name = "J17";
            this.J17.Size = new System.Drawing.Size(56, 41);
            this.J17.TabIndex = 20;
            // 
            // J16
            // 
            this.J16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J16.Location = new System.Drawing.Point(278, 142);
            this.J16.Name = "J16";
            this.J16.Size = new System.Drawing.Size(56, 41);
            this.J16.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(92, 325);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 31);
            this.button1.TabIndex = 24;
            this.button1.Text = "PREEMITIVE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(216, 325);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 31);
            this.button2.TabIndex = 25;
            this.button2.Text = "NON-PREEMITIVE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(431, 489);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.J20);
            this.Controls.Add(this.J19);
            this.Controls.Add(this.J18);
            this.Controls.Add(this.J17);
            this.Controls.Add(this.J16);
            this.Controls.Add(this.J15);
            this.Controls.Add(this.J14);
            this.Controls.Add(this.J13);
            this.Controls.Add(this.J12);
            this.Controls.Add(this.J11);
            this.Controls.Add(this.J10);
            this.Controls.Add(this.J9);
            this.Controls.Add(this.J8);
            this.Controls.Add(this.J7);
            this.Controls.Add(this.J6);
            this.Controls.Add(this.J5);
            this.Controls.Add(this.J4);
            this.Controls.Add(this.J3);
            this.Controls.Add(this.J2);
            this.Controls.Add(this.J1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TABLE";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox J1;
        private System.Windows.Forms.TextBox J2;
        private System.Windows.Forms.TextBox J3;
        private System.Windows.Forms.TextBox J4;
        private System.Windows.Forms.TextBox J5;
        private System.Windows.Forms.TextBox J10;
        private System.Windows.Forms.TextBox J9;
        private System.Windows.Forms.TextBox J8;
        private System.Windows.Forms.TextBox J7;
        private System.Windows.Forms.TextBox J6;
        private System.Windows.Forms.TextBox J15;
        private System.Windows.Forms.TextBox J14;
        private System.Windows.Forms.TextBox J13;
        private System.Windows.Forms.TextBox J12;
        private System.Windows.Forms.TextBox J11;
        private System.Windows.Forms.TextBox J20;
        private System.Windows.Forms.TextBox J19;
        private System.Windows.Forms.TextBox J18;
        private System.Windows.Forms.TextBox J17;
        private System.Windows.Forms.TextBox J16;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

