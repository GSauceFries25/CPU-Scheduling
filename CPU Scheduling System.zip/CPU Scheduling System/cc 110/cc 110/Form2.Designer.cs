﻿
namespace cc_110
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.A1 = new System.Windows.Forms.TextBox();
            this.A2 = new System.Windows.Forms.TextBox();
            this.A3 = new System.Windows.Forms.TextBox();
            this.A4 = new System.Windows.Forms.TextBox();
            this.A5 = new System.Windows.Forms.TextBox();
            this.B4 = new System.Windows.Forms.TextBox();
            this.B3 = new System.Windows.Forms.TextBox();
            this.B2 = new System.Windows.Forms.TextBox();
            this.B1 = new System.Windows.Forms.TextBox();
            this.B0 = new System.Windows.Forms.TextBox();
            this.B5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.JJ20 = new System.Windows.Forms.TextBox();
            this.JJ19 = new System.Windows.Forms.TextBox();
            this.JJ18 = new System.Windows.Forms.TextBox();
            this.JJ17 = new System.Windows.Forms.TextBox();
            this.JJ16 = new System.Windows.Forms.TextBox();
            this.JJ15 = new System.Windows.Forms.TextBox();
            this.JJ14 = new System.Windows.Forms.TextBox();
            this.JJ13 = new System.Windows.Forms.TextBox();
            this.JJ12 = new System.Windows.Forms.TextBox();
            this.JJ11 = new System.Windows.Forms.TextBox();
            this.JJ10 = new System.Windows.Forms.TextBox();
            this.JJ9 = new System.Windows.Forms.TextBox();
            this.JJ8 = new System.Windows.Forms.TextBox();
            this.JJ7 = new System.Windows.Forms.TextBox();
            this.JJ6 = new System.Windows.Forms.TextBox();
            this.JJ5 = new System.Windows.Forms.TextBox();
            this.JJ4 = new System.Windows.Forms.TextBox();
            this.JJ3 = new System.Windows.Forms.TextBox();
            this.JJ2 = new System.Windows.Forms.TextBox();
            this.JJ1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(-19, 341);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(520, 18);
            this.label5.TabIndex = 52;
            this.label5.Text = "________________________________________________________________";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(144, 377);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(195, 29);
            this.label6.TabIndex = 53;
            this.label6.Text = "GANTT CHART";
            // 
            // A1
            // 
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(67, 442);
            this.A1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(62, 34);
            this.A1.TabIndex = 54;
            // 
            // A2
            // 
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(137, 442);
            this.A2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(62, 34);
            this.A2.TabIndex = 55;
            // 
            // A3
            // 
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(207, 442);
            this.A3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(62, 34);
            this.A3.TabIndex = 56;
            // 
            // A4
            // 
            this.A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(277, 442);
            this.A4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(62, 34);
            this.A4.TabIndex = 57;
            // 
            // A5
            // 
            this.A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(346, 442);
            this.A5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(62, 34);
            this.A5.TabIndex = 58;
            // 
            // B4
            // 
            this.B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(316, 487);
            this.B4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(62, 34);
            this.B4.TabIndex = 63;
            // 
            // B3
            // 
            this.B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(247, 487);
            this.B3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(62, 34);
            this.B3.TabIndex = 62;
            // 
            // B2
            // 
            this.B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(176, 487);
            this.B2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(62, 34);
            this.B2.TabIndex = 61;
            // 
            // B1
            // 
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(107, 487);
            this.B1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(62, 34);
            this.B1.TabIndex = 60;
            // 
            // B0
            // 
            this.B0.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B0.Location = new System.Drawing.Point(37, 487);
            this.B0.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.B0.Name = "B0";
            this.B0.Size = new System.Drawing.Size(62, 34);
            this.B0.TabIndex = 59;
            // 
            // B5
            // 
            this.B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(386, 487);
            this.B5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(62, 34);
            this.B5.TabIndex = 64;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(200, 548);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 26);
            this.button1.TabIndex = 65;
            this.button1.Text = "COMPUTE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // JJ20
            // 
            this.JJ20.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ20.Location = new System.Drawing.Point(309, 242);
            this.JJ20.Name = "JJ20";
            this.JJ20.Size = new System.Drawing.Size(56, 41);
            this.JJ20.TabIndex = 89;
            // 
            // JJ19
            // 
            this.JJ19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ19.Location = new System.Drawing.Point(309, 208);
            this.JJ19.Name = "JJ19";
            this.JJ19.Size = new System.Drawing.Size(56, 41);
            this.JJ19.TabIndex = 88;
            // 
            // JJ18
            // 
            this.JJ18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ18.Location = new System.Drawing.Point(309, 174);
            this.JJ18.Name = "JJ18";
            this.JJ18.Size = new System.Drawing.Size(56, 41);
            this.JJ18.TabIndex = 87;
            // 
            // JJ17
            // 
            this.JJ17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ17.Location = new System.Drawing.Point(309, 140);
            this.JJ17.Name = "JJ17";
            this.JJ17.Size = new System.Drawing.Size(56, 41);
            this.JJ17.TabIndex = 86;
            // 
            // JJ16
            // 
            this.JJ16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ16.Location = new System.Drawing.Point(309, 106);
            this.JJ16.Name = "JJ16";
            this.JJ16.Size = new System.Drawing.Size(56, 41);
            this.JJ16.TabIndex = 85;
            // 
            // JJ15
            // 
            this.JJ15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ15.Location = new System.Drawing.Point(247, 242);
            this.JJ15.Name = "JJ15";
            this.JJ15.Size = new System.Drawing.Size(56, 41);
            this.JJ15.TabIndex = 84;
            // 
            // JJ14
            // 
            this.JJ14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ14.Location = new System.Drawing.Point(247, 208);
            this.JJ14.Name = "JJ14";
            this.JJ14.Size = new System.Drawing.Size(56, 41);
            this.JJ14.TabIndex = 83;
            // 
            // JJ13
            // 
            this.JJ13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ13.Location = new System.Drawing.Point(247, 174);
            this.JJ13.Name = "JJ13";
            this.JJ13.Size = new System.Drawing.Size(56, 41);
            this.JJ13.TabIndex = 82;
            // 
            // JJ12
            // 
            this.JJ12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ12.Location = new System.Drawing.Point(247, 140);
            this.JJ12.Name = "JJ12";
            this.JJ12.Size = new System.Drawing.Size(56, 41);
            this.JJ12.TabIndex = 81;
            // 
            // JJ11
            // 
            this.JJ11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ11.Location = new System.Drawing.Point(247, 106);
            this.JJ11.Name = "JJ11";
            this.JJ11.Size = new System.Drawing.Size(56, 41);
            this.JJ11.TabIndex = 80;
            // 
            // JJ10
            // 
            this.JJ10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ10.Location = new System.Drawing.Point(185, 242);
            this.JJ10.Name = "JJ10";
            this.JJ10.Size = new System.Drawing.Size(56, 41);
            this.JJ10.TabIndex = 79;
            // 
            // JJ9
            // 
            this.JJ9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ9.Location = new System.Drawing.Point(185, 208);
            this.JJ9.Name = "JJ9";
            this.JJ9.Size = new System.Drawing.Size(56, 41);
            this.JJ9.TabIndex = 78;
            // 
            // JJ8
            // 
            this.JJ8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ8.Location = new System.Drawing.Point(185, 174);
            this.JJ8.Name = "JJ8";
            this.JJ8.Size = new System.Drawing.Size(56, 41);
            this.JJ8.TabIndex = 77;
            // 
            // JJ7
            // 
            this.JJ7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ7.Location = new System.Drawing.Point(185, 140);
            this.JJ7.Name = "JJ7";
            this.JJ7.Size = new System.Drawing.Size(56, 41);
            this.JJ7.TabIndex = 76;
            // 
            // JJ6
            // 
            this.JJ6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ6.Location = new System.Drawing.Point(185, 106);
            this.JJ6.Name = "JJ6";
            this.JJ6.Size = new System.Drawing.Size(56, 41);
            this.JJ6.TabIndex = 75;
            // 
            // JJ5
            // 
            this.JJ5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ5.Location = new System.Drawing.Point(123, 242);
            this.JJ5.Name = "JJ5";
            this.JJ5.Size = new System.Drawing.Size(56, 41);
            this.JJ5.TabIndex = 74;
            // 
            // JJ4
            // 
            this.JJ4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ4.Location = new System.Drawing.Point(123, 208);
            this.JJ4.Name = "JJ4";
            this.JJ4.Size = new System.Drawing.Size(56, 41);
            this.JJ4.TabIndex = 73;
            // 
            // JJ3
            // 
            this.JJ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ3.Location = new System.Drawing.Point(123, 174);
            this.JJ3.Name = "JJ3";
            this.JJ3.Size = new System.Drawing.Size(56, 41);
            this.JJ3.TabIndex = 72;
            // 
            // JJ2
            // 
            this.JJ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ2.Location = new System.Drawing.Point(123, 140);
            this.JJ2.Name = "JJ2";
            this.JJ2.Size = new System.Drawing.Size(56, 41);
            this.JJ2.TabIndex = 71;
            // 
            // JJ1
            // 
            this.JJ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JJ1.Location = new System.Drawing.Point(123, 106);
            this.JJ1.Name = "JJ1";
            this.JJ1.Size = new System.Drawing.Size(56, 41);
            this.JJ1.TabIndex = 70;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(319, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 17);
            this.label4.TabIndex = 69;
            this.label4.Text = "AT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(260, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 17);
            this.label3.TabIndex = 68;
            this.label3.Text = "AT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(198, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 17);
            this.label2.TabIndex = 67;
            this.label2.Text = "BT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(120, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 66;
            this.label1.Text = "JOBS";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(478, 604);
            this.Controls.Add(this.JJ20);
            this.Controls.Add(this.JJ19);
            this.Controls.Add(this.JJ18);
            this.Controls.Add(this.JJ17);
            this.Controls.Add(this.JJ16);
            this.Controls.Add(this.JJ15);
            this.Controls.Add(this.JJ14);
            this.Controls.Add(this.JJ13);
            this.Controls.Add(this.JJ12);
            this.Controls.Add(this.JJ11);
            this.Controls.Add(this.JJ10);
            this.Controls.Add(this.JJ9);
            this.Controls.Add(this.JJ8);
            this.Controls.Add(this.JJ7);
            this.Controls.Add(this.JJ6);
            this.Controls.Add(this.JJ5);
            this.Controls.Add(this.JJ4);
            this.Controls.Add(this.JJ3);
            this.Controls.Add(this.JJ2);
            this.Controls.Add(this.JJ1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.B0);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GANTT CHART";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox A1;
        private System.Windows.Forms.TextBox A2;
        private System.Windows.Forms.TextBox A3;
        private System.Windows.Forms.TextBox A4;
        private System.Windows.Forms.TextBox A5;
        private System.Windows.Forms.TextBox B4;
        private System.Windows.Forms.TextBox B3;
        private System.Windows.Forms.TextBox B2;
        private System.Windows.Forms.TextBox B1;
        private System.Windows.Forms.TextBox B0;
        private System.Windows.Forms.TextBox B5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox JJ20;
        private System.Windows.Forms.TextBox JJ19;
        private System.Windows.Forms.TextBox JJ18;
        private System.Windows.Forms.TextBox JJ17;
        private System.Windows.Forms.TextBox JJ16;
        private System.Windows.Forms.TextBox JJ15;
        private System.Windows.Forms.TextBox JJ14;
        private System.Windows.Forms.TextBox JJ13;
        private System.Windows.Forms.TextBox JJ12;
        private System.Windows.Forms.TextBox JJ11;
        private System.Windows.Forms.TextBox JJ10;
        private System.Windows.Forms.TextBox JJ9;
        private System.Windows.Forms.TextBox JJ8;
        private System.Windows.Forms.TextBox JJ7;
        private System.Windows.Forms.TextBox JJ6;
        private System.Windows.Forms.TextBox JJ5;
        private System.Windows.Forms.TextBox JJ4;
        private System.Windows.Forms.TextBox JJ3;
        private System.Windows.Forms.TextBox JJ2;
        private System.Windows.Forms.TextBox JJ1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}