﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cc_110
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(E6.Text);
            int b = Convert.ToInt32(E11.Text);
            E16.Text = Convert.ToString(a - b);

            int c = Convert.ToInt32(E7.Text);
            int d = Convert.ToInt32(E12.Text);
            E17.Text = Convert.ToString(c - d);

            int aa = Convert.ToInt32(E8.Text);
            int bb = Convert.ToInt32(E13.Text);
            E18.Text = Convert.ToString(aa - bb);

            int ab = Convert.ToInt32(E9.Text);
            int ba = Convert.ToInt32(E14.Text);
            E19.Text = Convert.ToString(ab - ba);

            int aaa = Convert.ToInt32(E10.Text);
            int bbb = Convert.ToInt32(E15.Text);
            E20.Text = Convert.ToString(aaa - bbb);

            int z = Convert.ToInt32(E16.Text);
            int x = Convert.ToInt32(E17.Text);
            int m = Convert.ToInt32(E18.Text);
            int o = Convert.ToInt32(E19.Text);
            int p = Convert.ToInt32(E20.Text);
            E21.Text = Convert.ToString(z + x + m + o + p);

            decimal num1 = Convert.ToDecimal(E21.Text);
            decimal num2 = Convert.ToDecimal(5);
            decimal answ = num1 / num2;
            E22.Text = answ.ToString() + "ms";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(T6.Text);
            int b = Convert.ToInt32(T11.Text);
            T16.Text = Convert.ToString(a - b);

            int c = Convert.ToInt32(T7.Text);
            int d = Convert.ToInt32(T12.Text);
            T17.Text = Convert.ToString(c - d);

            int aa = Convert.ToInt32(T8.Text);
            int bb = Convert.ToInt32(T13.Text);
            T18.Text = Convert.ToString(aa - bb);

            int ab = Convert.ToInt32(T9.Text);
            int ba = Convert.ToInt32(T14.Text);
            T19.Text = Convert.ToString(ab - ba);

            int aaa = Convert.ToInt32(T10.Text);
            int bbb = Convert.ToInt32(T15.Text);
            T20.Text = Convert.ToString(aaa - bbb);

            int z = Convert.ToInt32(T16.Text);
            int x = Convert.ToInt32(T17.Text);
            int m = Convert.ToInt32(T18.Text);
            int o = Convert.ToInt32(T19.Text);
            int p = Convert.ToInt32(T20.Text);
            T21.Text = Convert.ToString(z + x + m + o + p);

            decimal num1 = Convert.ToDecimal(T21.Text);
            decimal num2 = Convert.ToDecimal(5);
            decimal answ = num1 / num2;
            T22.Text = answ.ToString() + "ms";

        }
    }
}
