﻿
namespace cc_110
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.K19 = new System.Windows.Forms.TextBox();
            this.K18 = new System.Windows.Forms.TextBox();
            this.K17 = new System.Windows.Forms.TextBox();
            this.K16 = new System.Windows.Forms.TextBox();
            this.K15 = new System.Windows.Forms.TextBox();
            this.K14 = new System.Windows.Forms.TextBox();
            this.K13 = new System.Windows.Forms.TextBox();
            this.K12 = new System.Windows.Forms.TextBox();
            this.K11 = new System.Windows.Forms.TextBox();
            this.K10 = new System.Windows.Forms.TextBox();
            this.K9 = new System.Windows.Forms.TextBox();
            this.K8 = new System.Windows.Forms.TextBox();
            this.K7 = new System.Windows.Forms.TextBox();
            this.K6 = new System.Windows.Forms.TextBox();
            this.K5 = new System.Windows.Forms.TextBox();
            this.K4 = new System.Windows.Forms.TextBox();
            this.K3 = new System.Windows.Forms.TextBox();
            this.K2 = new System.Windows.Forms.TextBox();
            this.K1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Q5 = new System.Windows.Forms.TextBox();
            this.Q4 = new System.Windows.Forms.TextBox();
            this.Q3 = new System.Windows.Forms.TextBox();
            this.Q2 = new System.Windows.Forms.TextBox();
            this.Q1 = new System.Windows.Forms.TextBox();
            this.Q0 = new System.Windows.Forms.TextBox();
            this.X5 = new System.Windows.Forms.TextBox();
            this.X4 = new System.Windows.Forms.TextBox();
            this.X3 = new System.Windows.Forms.TextBox();
            this.X2 = new System.Windows.Forms.TextBox();
            this.X1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.KK20 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // K19
            // 
            this.K19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K19.Location = new System.Drawing.Point(310, 169);
            this.K19.Name = "K19";
            this.K19.Size = new System.Drawing.Size(56, 41);
            this.K19.TabIndex = 126;
            // 
            // K18
            // 
            this.K18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K18.Location = new System.Drawing.Point(310, 135);
            this.K18.Name = "K18";
            this.K18.Size = new System.Drawing.Size(56, 41);
            this.K18.TabIndex = 125;
            // 
            // K17
            // 
            this.K17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K17.Location = new System.Drawing.Point(310, 101);
            this.K17.Name = "K17";
            this.K17.Size = new System.Drawing.Size(56, 41);
            this.K17.TabIndex = 124;
            // 
            // K16
            // 
            this.K16.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K16.Location = new System.Drawing.Point(310, 67);
            this.K16.Name = "K16";
            this.K16.Size = new System.Drawing.Size(56, 41);
            this.K16.TabIndex = 123;
            // 
            // K15
            // 
            this.K15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K15.Location = new System.Drawing.Point(248, 203);
            this.K15.Name = "K15";
            this.K15.Size = new System.Drawing.Size(56, 41);
            this.K15.TabIndex = 122;
            // 
            // K14
            // 
            this.K14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K14.Location = new System.Drawing.Point(248, 169);
            this.K14.Name = "K14";
            this.K14.Size = new System.Drawing.Size(56, 41);
            this.K14.TabIndex = 121;
            // 
            // K13
            // 
            this.K13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K13.Location = new System.Drawing.Point(248, 135);
            this.K13.Name = "K13";
            this.K13.Size = new System.Drawing.Size(56, 41);
            this.K13.TabIndex = 120;
            // 
            // K12
            // 
            this.K12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K12.Location = new System.Drawing.Point(248, 101);
            this.K12.Name = "K12";
            this.K12.Size = new System.Drawing.Size(56, 41);
            this.K12.TabIndex = 119;
            // 
            // K11
            // 
            this.K11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K11.Location = new System.Drawing.Point(248, 67);
            this.K11.Name = "K11";
            this.K11.Size = new System.Drawing.Size(56, 41);
            this.K11.TabIndex = 118;
            // 
            // K10
            // 
            this.K10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K10.Location = new System.Drawing.Point(186, 203);
            this.K10.Name = "K10";
            this.K10.Size = new System.Drawing.Size(56, 41);
            this.K10.TabIndex = 117;
            // 
            // K9
            // 
            this.K9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K9.Location = new System.Drawing.Point(186, 169);
            this.K9.Name = "K9";
            this.K9.Size = new System.Drawing.Size(56, 41);
            this.K9.TabIndex = 116;
            // 
            // K8
            // 
            this.K8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K8.Location = new System.Drawing.Point(186, 135);
            this.K8.Name = "K8";
            this.K8.Size = new System.Drawing.Size(56, 41);
            this.K8.TabIndex = 115;
            // 
            // K7
            // 
            this.K7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K7.Location = new System.Drawing.Point(186, 101);
            this.K7.Name = "K7";
            this.K7.Size = new System.Drawing.Size(56, 41);
            this.K7.TabIndex = 114;
            // 
            // K6
            // 
            this.K6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K6.Location = new System.Drawing.Point(186, 67);
            this.K6.Name = "K6";
            this.K6.Size = new System.Drawing.Size(56, 41);
            this.K6.TabIndex = 113;
            // 
            // K5
            // 
            this.K5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K5.Location = new System.Drawing.Point(124, 203);
            this.K5.Name = "K5";
            this.K5.Size = new System.Drawing.Size(56, 41);
            this.K5.TabIndex = 112;
            // 
            // K4
            // 
            this.K4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K4.Location = new System.Drawing.Point(124, 169);
            this.K4.Name = "K4";
            this.K4.Size = new System.Drawing.Size(56, 41);
            this.K4.TabIndex = 111;
            // 
            // K3
            // 
            this.K3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K3.Location = new System.Drawing.Point(124, 135);
            this.K3.Name = "K3";
            this.K3.Size = new System.Drawing.Size(56, 41);
            this.K3.TabIndex = 110;
            // 
            // K2
            // 
            this.K2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K2.Location = new System.Drawing.Point(124, 101);
            this.K2.Name = "K2";
            this.K2.Size = new System.Drawing.Size(56, 41);
            this.K2.TabIndex = 109;
            // 
            // K1
            // 
            this.K1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K1.Location = new System.Drawing.Point(124, 67);
            this.K1.Name = "K1";
            this.K1.Size = new System.Drawing.Size(56, 41);
            this.K1.TabIndex = 108;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(320, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 17);
            this.label4.TabIndex = 107;
            this.label4.Text = "AT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(261, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 17);
            this.label3.TabIndex = 106;
            this.label3.Text = "AT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(199, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 17);
            this.label2.TabIndex = 105;
            this.label2.Text = "BT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(121, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 104;
            this.label1.Text = "JOBS";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(207, 522);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 26);
            this.button1.TabIndex = 103;
            this.button1.Text = "COMPUTE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Q5
            // 
            this.Q5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q5.Location = new System.Drawing.Point(393, 461);
            this.Q5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Q5.Name = "Q5";
            this.Q5.Size = new System.Drawing.Size(62, 34);
            this.Q5.TabIndex = 102;
            // 
            // Q4
            // 
            this.Q4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q4.Location = new System.Drawing.Point(323, 461);
            this.Q4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Q4.Name = "Q4";
            this.Q4.Size = new System.Drawing.Size(62, 34);
            this.Q4.TabIndex = 101;
            // 
            // Q3
            // 
            this.Q3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3.Location = new System.Drawing.Point(254, 461);
            this.Q3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Q3.Name = "Q3";
            this.Q3.Size = new System.Drawing.Size(62, 34);
            this.Q3.TabIndex = 100;
            // 
            // Q2
            // 
            this.Q2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q2.Location = new System.Drawing.Point(183, 461);
            this.Q2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Q2.Name = "Q2";
            this.Q2.Size = new System.Drawing.Size(62, 34);
            this.Q2.TabIndex = 99;
            // 
            // Q1
            // 
            this.Q1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q1.Location = new System.Drawing.Point(114, 461);
            this.Q1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Q1.Name = "Q1";
            this.Q1.Size = new System.Drawing.Size(62, 34);
            this.Q1.TabIndex = 98;
            // 
            // Q0
            // 
            this.Q0.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q0.Location = new System.Drawing.Point(44, 461);
            this.Q0.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Q0.Name = "Q0";
            this.Q0.Size = new System.Drawing.Size(62, 34);
            this.Q0.TabIndex = 97;
            // 
            // X5
            // 
            this.X5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X5.Location = new System.Drawing.Point(353, 416);
            this.X5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.X5.Name = "X5";
            this.X5.Size = new System.Drawing.Size(62, 34);
            this.X5.TabIndex = 96;
            // 
            // X4
            // 
            this.X4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X4.Location = new System.Drawing.Point(284, 416);
            this.X4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.X4.Name = "X4";
            this.X4.Size = new System.Drawing.Size(62, 34);
            this.X4.TabIndex = 95;
            // 
            // X3
            // 
            this.X3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X3.Location = new System.Drawing.Point(214, 416);
            this.X3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.X3.Name = "X3";
            this.X3.Size = new System.Drawing.Size(62, 34);
            this.X3.TabIndex = 94;
            // 
            // X2
            // 
            this.X2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X2.Location = new System.Drawing.Point(144, 416);
            this.X2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.X2.Name = "X2";
            this.X2.Size = new System.Drawing.Size(62, 34);
            this.X2.TabIndex = 93;
            // 
            // X1
            // 
            this.X1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X1.Location = new System.Drawing.Point(74, 416);
            this.X1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.X1.Name = "X1";
            this.X1.Size = new System.Drawing.Size(62, 34);
            this.X1.TabIndex = 92;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(151, 351);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(195, 29);
            this.label6.TabIndex = 91;
            this.label6.Text = "GANTT CHART";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(-21, 287);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(520, 17);
            this.label5.TabIndex = 90;
            this.label5.Text = "________________________________________________________________";
            // 
            // KK20
            // 
            this.KK20.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KK20.Location = new System.Drawing.Point(310, 203);
            this.KK20.Name = "KK20";
            this.KK20.Size = new System.Drawing.Size(56, 41);
            this.KK20.TabIndex = 127;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(493, 616);
            this.Controls.Add(this.KK20);
            this.Controls.Add(this.K19);
            this.Controls.Add(this.K18);
            this.Controls.Add(this.K17);
            this.Controls.Add(this.K16);
            this.Controls.Add(this.K15);
            this.Controls.Add(this.K14);
            this.Controls.Add(this.K13);
            this.Controls.Add(this.K12);
            this.Controls.Add(this.K11);
            this.Controls.Add(this.K10);
            this.Controls.Add(this.K9);
            this.Controls.Add(this.K8);
            this.Controls.Add(this.K7);
            this.Controls.Add(this.K6);
            this.Controls.Add(this.K5);
            this.Controls.Add(this.K4);
            this.Controls.Add(this.K3);
            this.Controls.Add(this.K2);
            this.Controls.Add(this.K1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Q5);
            this.Controls.Add(this.Q4);
            this.Controls.Add(this.Q3);
            this.Controls.Add(this.Q2);
            this.Controls.Add(this.Q1);
            this.Controls.Add(this.Q0);
            this.Controls.Add(this.X5);
            this.Controls.Add(this.X4);
            this.Controls.Add(this.X3);
            this.Controls.Add(this.X2);
            this.Controls.Add(this.X1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NP COMPUTATION";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox K19;
        private System.Windows.Forms.TextBox K18;
        private System.Windows.Forms.TextBox K17;
        private System.Windows.Forms.TextBox K16;
        private System.Windows.Forms.TextBox K15;
        private System.Windows.Forms.TextBox K14;
        private System.Windows.Forms.TextBox K13;
        private System.Windows.Forms.TextBox K12;
        private System.Windows.Forms.TextBox K11;
        private System.Windows.Forms.TextBox K10;
        private System.Windows.Forms.TextBox K9;
        private System.Windows.Forms.TextBox K8;
        private System.Windows.Forms.TextBox K7;
        private System.Windows.Forms.TextBox K6;
        private System.Windows.Forms.TextBox K5;
        private System.Windows.Forms.TextBox K4;
        private System.Windows.Forms.TextBox K3;
        private System.Windows.Forms.TextBox K2;
        private System.Windows.Forms.TextBox K1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Q5;
        private System.Windows.Forms.TextBox Q4;
        private System.Windows.Forms.TextBox Q3;
        private System.Windows.Forms.TextBox Q2;
        private System.Windows.Forms.TextBox Q1;
        private System.Windows.Forms.TextBox Q0;
        private System.Windows.Forms.TextBox X5;
        private System.Windows.Forms.TextBox X4;
        private System.Windows.Forms.TextBox X3;
        private System.Windows.Forms.TextBox X2;
        private System.Windows.Forms.TextBox X1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox KK20;
    }
}